<template>
    <div class="container px-5 main-container my-5">
        <div class="row justify-content-center align-items-center my-5">
            <div class="col-md-6 main-img p-0 m-1">
                <img src="/image/main.JPG" alt="">
            </div>
            <p class="col-md-6 p-5 m-0 text-center">
                <span class="p-2 main-span mx-2">這裡提供貼文業配服務。</span>
                <span class="p-2 main-span mx-2">Wendyです。</span>
            </p>
        </div>
        <div class="row justify-content-evenly align-items-center">
            <div class="col-md-6">
                <p>Drama Note 成立於2020年1月，累績至今已有<span class="highlight-span py-1 fw-bold">1.3萬粉絲</span>。
                </p>
                <p>粉專題材主要是日本文化、日本娛樂、日文學習相關，影劇方面則多方涉獵，舉凡美劇、韓劇、台劇、電影都有觀賞。</p>
                <p>
                    個人興趣廣泛，歡迎來信提案合作機會。
                </p>
            </div>
            <div class="col-md-6 main-img2 p-0">
                <img src="/image/TKLPAR59463-Edit_TP_V4.jpg" alt="">
            </div>

        </div>
    </div>
    <!-- section -->
    <div class="container menu-section py-5 my-5">
        <h2 class="text-center p-3">MENU</h2>
        <div class="menu-img mx-3"></div>

        <h3 class="text-center my-5">SERVICE</h3>


        <div class="row mx-3">
            <div class="col-md-3 text-center p-2">
                <img class="rounded-circle my-5" src="/image/ig-story.jpg" alt="" width="150" height="150">
                <h4 class="eng-font">IG STORY</h4>
                <p>限時動態並帶連結露出</p>
                <div class="price-card p-3 my-5">
                    <h5 class="my-2 eng-font text-light">PRICE</h5>
                    <p class="my-2">2000元/則</p>
                </div>
                <button class="add-cart-btn">加入購物車</button>
            </div>

            <div class="col-md-3 text-center p-2">
                <img class="rounded-circle my-5" src="/image/instagram.jpg" alt="" width="150" height="150">
                <h4 class="eng-font">IG POST</h4>
                <p>多圖貼文一則</p>
                <div class="price-card p-3 my-5">
                    <h5 class="my-2 eng-font text-light">PRICE</h5>
                    <p class="my-2">10000元/則</p>
                </div>
                <button class="add-cart-btn">加入購物車</button>

            </div>
            <div class="col-md-3 text-center p-2">
                <img class="rounded-circle my-5" src="/image/blog-platform.jpg" alt="" width="150" height="150">
                <h4 class="eng-font">BLOG</h4>
                <p>SEO文章一則</p>
                <div class="price-card p-3 my-5">
                    <h5 class="my-2 eng-font text-light">PRICE</h5>
                    <p class="my-2">5000元/則</p>
                </div>
                <button class="add-cart-btn">加入購物車</button>

            </div>
            <div class="col-md-3 text-center p-2">
                <img class="rounded-circle my-5" src="/image/video.jpg" alt="" width="150" height="150">
                <h4 class="eng-font">YOUTUBE</h4>
                <p>剪接一支影片</p>
                <div class="price-card p-3 my-5">
                    <h5 class="my-2 eng-font text-light">PRICE</h5>
                    <p class="my-2">5000元/分</p>
                </div>
                <button class="add-cart-btn">加入購物車</button>

            </div>
        </div>
    </div>
    <!-- flow -->
    <div class="cart-container">
        <div class="container">
            <div class="row text-center">
                <div class="flow-card col">
                    <h4 class="my-5 num-stroke-font fw-bold fs-2">01</h4>
                    <img class="text-center" src="/image/11213_color.svg" alt="" width="150" height="150">
                    <h5 class="my-4 kanji-font fw-bold">提案</h5>
                    <p>來信告知需求與方向</p>
                </div>
                <div class="flow-card col">
                    <h4 class="my-5 num-stroke-font fw-bold fs-2">02</h4>
                    <img src="/image/10264_color.svg" alt="" width="150" height="150">
                    <h5 class="my-4 kanji-font fw-bold">討論</h5>
                    <p>雙方討論確認共識</p>
                </div>
                <div class="flow-card col">
                    <h4 class="my-5 num-stroke-font fw-bold fs-2">03</h4>
                    <img src="/image/8194_color.svg" alt="" width="150" height="150">
                    <h5 class="my-4 kanji-font fw-bold">簽約</h5>
                    <p>定案後簽約，甲方支付50%訂金</p>
                </div>
                <div class="flow-card col">
                    <h4 class="my-5 num-stroke-font fw-bold fs-2">04</h4>
                    <img src="/image/10342_color.svg" alt="" width="150" height="150">
                    <h5 class="my-4 kanji-font fw-bold">開始製作</h5>
                    <p>修改限三次內，乙方於期限內完成製作</p>
                </div>
                <div class="flow-card col">
                    <h4 class="my-5 num-stroke-font fw-bold fs-2">05</h4>
                    <img src="/image/2782_color.svg" alt="" width="150" height="150">
                    <h5 class="my-4 kanji-font fw-bold">結案</h5>
                    <p>乙方提交後台數據，甲方支付尾款，完成合作</p>
                </div>

            </div>


        </div>

    </div>

    <div class="text-center m-5">
        <input type="text" class="p-2 m-3">
        <br>
        <button class="contact-btn m-3">Log In</button>
    </div>
</template>

<script>
export default {


    data() {
        return {
            publicPath: process.env.BASE_URL
        }
    },


}

</script>

<style>
.contact-btn {
    border: none;
    background-color: #4C4948;
    padding: 1rem 5rem;
    color: #fff;
    transition: .5s;
    font-family: 'Josefin Sans', sans-serif;
}

.contact-btn:hover {
    border-radius: 10px;
    transition: .5s;
}

.main-span {
    background-color: #fff;
    text-orientation: upright;
    writing-mode: vertical-lr;

}

.highlight-span {
    background-color: #FFF3AF;
}

.main-img {
    background-color: #efc591;
    overflow: hidden;
    object-fit: cover;
    border-radius: 50%;
    width: 300px;
    height: 300px;
}

.main-img>img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
}

.main-img2 {
    overflow: hidden;
    object-fit: cover;
    background-color: #efc591;
    border-radius: 50%;
    width: 200px;
    height: 200px;
}

.main-img2>img {
    width: 100%;
    height: 100%;
    border-radius: 50%;
}


.menu-section {
    background-color: #fff;
    border-radius: 20px;
}

.menu-img {
    background: url("~@/assets/image/ogasuta458A7738_TP_V4.jpg");
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    height: 500px;
    border-radius: 20px;
}

.price-card {
    background-color: #AFAFAF;
}

.price-card>* {
    color: #fff
}


.add-cart-btn {
    border: none;
    background-color: #4C4948;
    padding: 1rem 5rem;
    color: #fff;
    transition: .5s;
    font-family: 'Zen Maru Gothic', sans-serif;
}

.add-cart-btn:hover {
    border-radius: 10px;
    transition: .5s;
}

.cart-container {
    background-color: #FFFCF0;
}

input[type=text],
input[type=email] {
    border: none;
}

input[type=text]:focus {
    /* 無法顯示 */
    border: none;
}

footer {
    background-color: #4C4948;
}

.footer-btn {
    border: none;
    background-color: #fff;
    padding: 0.5rem 3rem;
    color: #4C4948;
    transition: .5s;
    font-family: 'Josefin Sans', sans-serif;
}

.footer-btn:hover {
    border-radius: 10px;
    transition: .5s;
}
</style>