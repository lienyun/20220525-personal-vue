<template>
<h3 class="m-5 text-center">購物車</h3>
    <div class="container">
      <table>
        <thead>
            <tr>
                <th>品項</th>
                <th>價錢</th>
                <th>總價</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>IG貼文</td>
                <td>2000</td>
                <td>2000</td>
            </tr>
        </tbody>
    </table>
    </div>


</template>