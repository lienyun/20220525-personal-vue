<template>
    <div class="text-center">
        <h3 class="m-5">註冊</h3>
        <label for="">Email</label>
        <br>
        <input type="email">
        <br>
        <label for="">密碼</label>
        <br>
        <input type="text">
        <br>
        <button type="submit" class="m-3">註冊</button>
    </div>
</template>

<style>

</style>